 <ul class="text-right">
    <div class="adminform">
        <a href="Home.php" class="text-right" value="">
        <?php  echo $_SESSION['admin_name'];?></a>
           <a href="Home.php">&nbsp;<span class="glyphicon glyphicon-chevron-down"></span></a>
           <a href="adminlogin.php">Logout</a>&nbsp;<span class="glyphicon glyphicon-chevron-down"></span>
     </div>
  </ul>