      <div class="text-center" style="font-family: Lucida Fax;">
          <h3 id="Anthony"><span style="color:black;"><b class="m">Barangay</b> <b class="n">Tabunok</b> </span><span style="color:black;"><b class="o">Management</b> </span><span style="color:black;"><b class="p">System</b>	</span></h3>

          <style>
          	.m{
  				color: black;
  				text-shadow: 0 0 6px orange;
          	}
          	.n{
          		color: black;
          		text-shadow: 0 0 6px orange;
          	}
          	.o{
          		color: black;
          		text-shadow: 0 0 6px orange;
          	}
          	.p{
          		color: black;
          		text-shadow: 0 0 6px orange;
          	}

          </style>
      </div>
	